from django.apps import AppConfig


class GeoappConfig(AppConfig):
    name = 'geoApp'
