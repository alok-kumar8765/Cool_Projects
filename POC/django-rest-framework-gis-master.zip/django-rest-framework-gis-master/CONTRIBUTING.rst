Contributing
============

Thanks for your interest! We love contributions, so please feel free to fix bugs, improve things, provide documentation. Just `follow the
guidelines <https://github.com/openwisp/django-rest-framework-gis#contributing>`_ and submit a PR.
