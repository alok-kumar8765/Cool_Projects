
# Importing boto3 library to make functionality available
import boto3
from awskeys import AWSAccessKeyId,AWSSecretKey ##awskeys.py is file made by me only not pre_defined
print("hello")
# Creating a client connection with AWS S3
# s3 = boto3.client('s3',aws_access_key_id=AWSAccessKeyId,
#          aws_secret_access_key= AWSSecretKey)
#####_____________________creating bucket__________________________________#########
# Creating a bucket
# print("hello1")
# s3.create_bucket(Bucket='first-bucket-second-ashish2')
# print("Bucket created succesfully")
#####_____________________list_buckets__________________________________#########
# # Importing boto3 library
# # import boto3
# # # Creating a client connection with AWS S3
# # s3 = boto3.client('s3')
# # Storing the client connection within rep
# response = s3.list_buckets()
# print(response)

# # Output the bucket names
# print('Existing buckets:')
# for bucket in response['Buckets']: # For Loop to list all the buckets
#     print(f'{bucket["Name"]}')
#####_____________________upload file in bucket on s3__________________________________#########
# # Read the file stored on your local machine
# with open('requirements.txt', 'rb') as data:
# # Upload the file ATA.txt within the Myfolder on S3
#     s3.upload_fileobj(data, 'first-bucket-second-ashish1', 'requirements.txt')
#     print(data)
# print("uploaded sucessfully")
#####______upload folder which is inside current directory . As zip ___________#########

# import os,zipfile
# def zipdir(path,ziph):
#     for root, dirs, files in os.walk(path):
#         for file in files:
#             ziph.write(os.path.join(root, file))
# zipf = zipfile.ZipFile('boto3pra1.zip', 'w', zipfile.ZIP_DEFLATED) 
# zipdir('boto3env',zipf)#NOte folder name should be in current directory   # Passing the boto3env folder in the arguments 

# zipf.close() #C:\Users\MicroApt\Downloads\my code\boto3practice\boto3practice.zip 
# with open('boto3pra1.zip', 'rb') as data:
    
#     s3.upload_fileobj(data, 'first-bucket-second-ashish1', 'boto3pra1.zip')

#####___1_first make connection with resource______2__copy file from one bucket to another bucket on s3__________________________________#########

# # Importing boto3 library
# import boto3
# # Creating the connection with the resource
# s3 = boto3.resource('s3',aws_access_key_id=AWSAccessKeyId,
#          aws_secret_access_key= AWSSecretKey)
# # # Declaring the source to be copied
# copy_source = {
#     'Bucket': 'first-bucket-second-ashish1',
#     'Key': 'requirements.txt'
# }
# bucket = s3.Bucket('first-bucket-second-ashish')
# # Copying the files to another bucket
# bucket.copy(copy_source, 'requ.zip')
# print("done")